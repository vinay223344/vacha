/**
 ******************************************************************************
 * @file    i2c_example.c
 * @brief   Usage examples for the STM32L41xxx I2C driver
 *
 * Demonstrates:
 *   1. Driver initialisation (PCLK1 = 80 MHz, 400 kHz Fast Mode)
 *   2. Bus probe / device-ready check
 *   3. Register write (e.g., configure a sensor)
 *   4. Register read  (e.g., read sensor data)
 *   5. Interrupt-mode master transmit with completion callback
 *   6. Slave mode (listen + receive)
 ******************************************************************************
 */

#include "stm32l41x_i2c.h"

/* ── Minimal SysTick stub for standalone compilation check ─────────────── */
static uint32_t tick_ms_counter = 0;

/* Replace with your RTOS / SysTick implementation */
static uint32_t get_tick(void) { return tick_ms_counter; }

/* ── RCC enable stubs (implement for your clock config) ─────────────────── */
static void rcc_enable_i2c1(void)
{
    /* APB1ENR1 bit 21 – I2C1EN */
    /* e.g.: RCC->APB1ENR1 |= (1UL << 21); */
}

static void gpio_init_i2c1_pins(void)
{
    /*
     * PB6  → I2C1_SCL  (AF4, open-drain, very-high speed, pull-up)
     * PB7  → I2C1_SDA  (AF4, open-drain, very-high speed, pull-up)
     *
     * Configure GPIOB MODER, OTYPER, OSPEEDR, PUPDR, AFR[0]
     * using your GPIO driver or direct register writes.
     */
}

/* ─────────────────────────────────────────────────────────────────────────
 * Handle declaration (global or static so callbacks can access it)
 * ───────────────────────────────────────────────────────────────────────── */
static I2C_Handle_t hi2c1;

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 1 – Initialise I2C1 at 400 kHz (PCLK1 = 80 MHz)
 * ───────────────────────────────────────────────────────────────────────── */
void Example_I2C_Init(void)
{
    rcc_enable_i2c1();
    gpio_init_i2c1_pins();

    hi2c1.instance    = I2C1;
    hi2c1.get_tick_ms = get_tick;

    hi2c1.config.timing        = I2C_TIMING_400K_80MHZ;
    hi2c1.config.addr_mode     = I2C_ADDR_7BIT;
    hi2c1.config.own_addr1     = 0;            /* master-only, no own addr */
    hi2c1.config.own_addr2     = 0;
    hi2c1.config.own_addr2_mask= 0;
    hi2c1.config.general_call  = false;
    hi2c1.config.no_stretch    = false;
    hi2c1.config.op_mode       = I2C_MODE_POLLING;
    hi2c1.config.dnf           = 0;            /* digital filter off       */
    hi2c1.config.analog_filter = true;         /* analog filter on         */

    /* Clear all callbacks */
    hi2c1.cb_master_tx_complete = NULL;
    hi2c1.cb_master_rx_complete = NULL;
    hi2c1.cb_slave_tx_complete  = NULL;
    hi2c1.cb_slave_rx_complete  = NULL;
    hi2c1.cb_addr_match         = NULL;
    hi2c1.cb_listen_complete    = NULL;
    hi2c1.cb_error              = NULL;

    I2C_Status_t st = I2C_Init(&hi2c1);
    (void)st;   /* check st == I2C_OK in production code */
}

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 2 – Probe the bus for a device at address 0x68 (e.g. MPU-6050)
 * ───────────────────────────────────────────────────────────────────────── */
void Example_Probe(void)
{
    I2C_Status_t st = I2C_IsDeviceReady(&hi2c1, 0x68, 3, I2C_TIMEOUT_MS);
    if (st == I2C_OK) {
        /* Device responded with ACK */
    } else {
        /* No device at 0x68 */
    }
}

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 3 – Write one byte to a register (e.g. MPU-6050 PWR_MGMT_1)
 * ───────────────────────────────────────────────────────────────────────── */
void Example_RegWrite(void)
{
    uint8_t val = 0x00;   /* clear PWR_MGMT_1: wake up sensor */
    I2C_Status_t st = I2C_Mem_Write(&hi2c1,
                                     0x68,    /* device address    */
                                     0x6B,    /* PWR_MGMT_1 reg    */
                                     1,       /* 1-byte reg addr   */
                                     &val, 1, /* data              */
                                     I2C_TIMEOUT_MS);
    (void)st;
}

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 4 – Read 6 bytes of accel data from MPU-6050 (ACCEL_XOUT_H 0x3B)
 * ───────────────────────────────────────────────────────────────────────── */
void Example_RegRead(void)
{
    uint8_t raw[6];
    I2C_Status_t st = I2C_Mem_Read(&hi2c1,
                                    0x68,
                                    0x3B,     /* ACCEL_XOUT_H      */
                                    1,        /* 1-byte reg addr   */
                                    raw, 6,
                                    I2C_TIMEOUT_MS);
    if (st == I2C_OK) {
        int16_t ax = (int16_t)((raw[0] << 8) | raw[1]);
        int16_t ay = (int16_t)((raw[2] << 8) | raw[3]);
        int16_t az = (int16_t)((raw[4] << 8) | raw[5]);
        (void)ax; (void)ay; (void)az;
    }
}

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 5 – Interrupt-mode transmit with completion callback
 * ───────────────────────────────────────────────────────────────────────── */
static volatile bool tx_done = false;

static void on_master_tx_complete(I2C_Handle_t *hi2c)
{
    (void)hi2c;
    tx_done = true;
    /* Signal semaphore / set event flag in an RTOS */
}

static void on_i2c_error(I2C_Handle_t *hi2c)
{
    I2C_Error_t err = I2C_GetError(hi2c);
    (void)err;
    /* Log or recover from error */
}

void Example_IT_Transmit(void)
{
    static const uint8_t payload[] = { 0x6B, 0x00 }; /* reg + value */

    hi2c1.config.op_mode        = I2C_MODE_INTERRUPT;
    hi2c1.cb_master_tx_complete = on_master_tx_complete;
    hi2c1.cb_error              = on_i2c_error;

    tx_done = false;
    I2C_Status_t st = I2C_Master_Transmit_IT(&hi2c1, 0x68,
                                               payload, sizeof(payload));
    if (st == I2C_OK) {
        /* Wait for completion (bare-metal spin or RTOS pend) */
        while (!tx_done) { /* yield / WFI */ }
    }
}

/* IRQ vectors — place in your vector table (startup file or NVIC registration) */
void I2C1_EV_IRQHandler(void) { I2C_EV_IRQHandler(&hi2c1); }
void I2C1_ER_IRQHandler(void) { I2C_ER_IRQHandler(&hi2c1); }

/* ─────────────────────────────────────────────────────────────────────────
 * EXAMPLE 6 – Slave receive (polling): listen for a master and store data
 * ───────────────────────────────────────────────────────────────────────── */
static I2C_Handle_t hi2c1_slave;

void Example_Slave_Init(void)
{
    hi2c1_slave.instance    = I2C1;
    hi2c1_slave.get_tick_ms = get_tick;

    hi2c1_slave.config.timing        = I2C_TIMING_400K_80MHZ;
    hi2c1_slave.config.addr_mode     = I2C_ADDR_7BIT;
    hi2c1_slave.config.own_addr1     = 0x55;   /* our slave address */
    hi2c1_slave.config.own_addr2     = 0;
    hi2c1_slave.config.own_addr2_mask= 0;
    hi2c1_slave.config.general_call  = false;
    hi2c1_slave.config.no_stretch    = false;
    hi2c1_slave.config.op_mode       = I2C_MODE_POLLING;
    hi2c1_slave.config.dnf           = 0;
    hi2c1_slave.config.analog_filter = true;

    I2C_Init(&hi2c1_slave);
}

void Example_Slave_Receive_Loop(void)
{
    uint8_t buf[32];
    while (1) {
        I2C_Status_t st = I2C_Slave_Receive(&hi2c1_slave, buf, sizeof(buf),
                                              1000 /* 1 s timeout */);
        if (st == I2C_OK) {
            /* Process received bytes in buf */
        }
    }
}

/* ─────────────────────────────────────────────────────────────────────────
 * main – ties examples together (remove as needed)
 * ───────────────────────────────────────────────────────────────────────── */
int main(void)
{
    Example_I2C_Init();
    Example_Probe();
    Example_RegWrite();
    Example_RegRead();
    Example_IT_Transmit();
    return 0;
}

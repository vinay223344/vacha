/**
 ******************************************************************************
 * @file    stm32l41x_i2c.c
 * @brief   I2C driver implementation for STM32L41xxx
 *
 * Reference Manual: RM0394 Rev 4
 *   Section 37   – Inter-integrated circuit (I2C) interface
 *   Section 37.4 – I2C master receiver/transmitter procedures
 *   Section 37.5 – Slave procedures
 ******************************************************************************
 */

#include "stm32l41x_i2c.h"

/* =========================================================================
 * Private Macros
 * ========================================================================= */

/** Read ISR, mask with flag, return non-zero if set */
#define I2C_FLAG_SET(hi2c, flag)    ((hi2c)->instance->ISR & (flag))

/** Millisecond elapsed check (handles 32-bit rollover) */
#define I2C_ELAPSED(start, now)     ((uint32_t)((now) - (start)))

/** Pack NBYTES into CR2 */
#define I2C_CR2_SET_NBYTES(n)       (((uint32_t)(n) << I2C_CR2_NBYTES_Pos) & I2C_CR2_NBYTES_Msk)

/** Set slave address in CR2 (7-bit: bits [7:1], 10-bit: bits [9:0]) */
#define I2C_CR2_SET_SADD7(addr)     (((uint32_t)(addr) << 1U) & 0xFEUL)
#define I2C_CR2_SET_SADD10(addr)    ((uint32_t)(addr) & 0x3FFUL)

/** Chunk size for reload transfers */
#define I2C_RELOAD_CHUNK            255U

/* =========================================================================
 * Private Helper: wait for a flag with timeout
 * ========================================================================= */
static I2C_Status_t i2c_wait_flag(I2C_Handle_t *hi2c, uint32_t flag,
                                   uint32_t set_or_clear, uint32_t timeout_ms)
{
    uint32_t start = hi2c->get_tick_ms();
    while (1) {
        uint32_t isr = hi2c->instance->ISR;

        /* Check for error flags first */
        if (isr & (I2C_ISR_BERR | I2C_ISR_ARLO | I2C_ISR_OVR)) {
            hi2c->error |= I2C_ERR_BERR;   /* simplified – caller checks */
            return I2C_FAIL;
        }
        if (isr & I2C_ISR_NACKF) {
            hi2c->instance->ICR = I2C_ICR_NACKCF | I2C_ICR_STOPCF;
            hi2c->error |= I2C_ERR_NACK;
            return I2C_FAIL;
        }

        /* Desired condition */
        if (set_or_clear) {
            if (isr & flag) return I2C_OK;
        } else {
            if (!(isr & flag)) return I2C_OK;
        }

        /* Timeout */
        if (I2C_ELAPSED(start, hi2c->get_tick_ms()) >= timeout_ms) {
            hi2c->error |= I2C_ERR_TIMEOUT;
            hi2c->state  = I2C_STATE_TIMEOUT;
            return I2C_TIMEOUT;
        }
    }
}

/* =========================================================================
 * Private Helper: ensure bus is free before starting a transfer
 * ========================================================================= */
static I2C_Status_t i2c_wait_bus_free(I2C_Handle_t *hi2c)
{
    return i2c_wait_flag(hi2c, I2C_ISR_BUSY, 0, I2C_BUS_FREE_TIMEOUT);
}

/* =========================================================================
 * Private Helper: configure CR2 and generate START for master mode
 * ========================================================================= */
static void i2c_master_request(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                I2C_Direction_t dir, uint8_t nbytes,
                                bool autoend, bool reload)
{
    uint32_t cr2 = 0;

    if (hi2c->config.addr_mode == I2C_ADDR_10BIT) {
        cr2  = I2C_CR2_ADD10;
        cr2 |= I2C_CR2_SET_SADD10(dev_addr);
    } else {
        cr2 |= I2C_CR2_SET_SADD7(dev_addr);
    }

    if (dir == I2C_DIR_READ)  cr2 |= I2C_CR2_RD_WRN;
    cr2 |= I2C_CR2_SET_NBYTES(nbytes);
    if (autoend) cr2 |= I2C_CR2_AUTOEND;
    if (reload)  cr2 |= I2C_CR2_RELOAD;
    cr2 |= I2C_CR2_START;

    hi2c->instance->CR2 = cr2;
}

/* =========================================================================
 * Private Helper: send N bytes of address (for Mem_Read/Mem_Write)
 * ========================================================================= */
static I2C_Status_t i2c_send_reg_addr(I2C_Handle_t *hi2c, uint16_t reg_addr,
                                       uint8_t reg_size, uint32_t timeout)
{
    if (reg_size == 2U) {
        if (i2c_wait_flag(hi2c, I2C_ISR_TXIS, 1, timeout) != I2C_OK) return I2C_FAIL;
        hi2c->instance->TXDR = (uint8_t)(reg_addr >> 8U);
    }
    if (i2c_wait_flag(hi2c, I2C_ISR_TXIS, 1, timeout) != I2C_OK) return I2C_FAIL;
    hi2c->instance->TXDR = (uint8_t)(reg_addr & 0xFFU);
    return I2C_OK;
}

/* =========================================================================
 * Private Helper: clear all error flags in ICR
 * ========================================================================= */
static void i2c_clear_errors(I2C_Handle_t *hi2c)
{
    hi2c->instance->ICR = I2C_ICR_BERRCF  | I2C_ICR_ARLOCF |
                          I2C_ICR_OVRCF   | I2C_ICR_PECCF  |
                          I2C_ICR_TIMOUTCF| I2C_ICR_NACKCF |
                          I2C_ICR_STOPCF  | I2C_ICR_ADDRCF |
                          I2C_ICR_ALERTCF;
}

/* =========================================================================
 * I2C_Init
 * ========================================================================= */
I2C_Status_t I2C_Init(I2C_Handle_t *hi2c)
{
    if (!hi2c || !hi2c->instance || !hi2c->get_tick_ms) return I2C_FAIL;

    /* 1. Disable peripheral before configuration (RM0394 §37.4.6) */
    hi2c->instance->CR1 &= ~I2C_CR1_PE;

    /* 2. Load timing register */
    hi2c->instance->TIMINGR = hi2c->config.timing;

    /* 3. Noise filters */
    uint32_t cr1 = 0;
    if (!hi2c->config.analog_filter)        cr1 |= I2C_CR1_ANFOFF;
    cr1 |= ((uint32_t)hi2c->config.dnf << I2C_CR1_DNF_Pos) & I2C_CR1_DNF_Msk;
    if (hi2c->config.no_stretch)            cr1 |= I2C_CR1_NOSTRETCH;
    if (hi2c->config.general_call)          cr1 |= I2C_CR1_GCEN;
    hi2c->instance->CR1 = cr1;

    /* 4. Own address 1 (slave) */
    if (hi2c->config.own_addr1 != 0U) {
        uint32_t oar1 = (1UL << 15);       /* OA1EN */
        if (hi2c->config.addr_mode == I2C_ADDR_10BIT)
            oar1 |= (1UL << 10) | (hi2c->config.own_addr1 & 0x3FFU);
        else
            oar1 |= ((hi2c->config.own_addr1 & 0x7FU) << 1U);
        hi2c->instance->OAR1 = oar1;
    }

    /* 5. Own address 2 (dual address) */
    if (hi2c->config.own_addr2 != 0U) {
        hi2c->instance->OAR2 =
            (1UL << 15) |                                          /* OA2EN */
            ((uint32_t)hi2c->config.own_addr2_mask << 8U) |
            ((hi2c->config.own_addr2 & 0x7EU));
    }

    /* 6. Enable peripheral */
    hi2c->instance->CR1 |= I2C_CR1_PE;

    /* 7. Reset state */
    hi2c->state = I2C_STATE_READY;
    hi2c->error = I2C_ERR_NONE;

    return I2C_OK;
}

/* =========================================================================
 * I2C_DeInit
 * ========================================================================= */
I2C_Status_t I2C_DeInit(I2C_Handle_t *hi2c)
{
    if (!hi2c || !hi2c->instance) return I2C_FAIL;
    hi2c->instance->CR1 &= ~I2C_CR1_PE;
    hi2c->state = I2C_STATE_RESET;
    hi2c->error = I2C_ERR_NONE;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Reset
 * ========================================================================= */
I2C_Status_t I2C_Reset(I2C_Handle_t *hi2c)
{
    I2C_DeInit(hi2c);
    return I2C_Init(hi2c);
}

/* =========================================================================
 * I2C_Master_Transmit  (polling)
 * RM0394 §37.4.2 – Master transmitter
 * ========================================================================= */
I2C_Status_t I2C_Master_Transmit(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                  const uint8_t *pdata, uint16_t size,
                                  uint32_t timeout)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_TX;
    hi2c->error = I2C_ERR_NONE;
    i2c_clear_errors(hi2c);

    uint16_t remaining = size;
    const uint8_t *ptr = pdata;

    while (remaining > 0) {
        uint8_t chunk = (remaining > I2C_RELOAD_CHUNK) ? I2C_RELOAD_CHUNK
                                                        : (uint8_t)remaining;
        bool last  = (remaining <= I2C_RELOAD_CHUNK);
        bool reload = !last;

        i2c_master_request(hi2c, dev_addr, I2C_DIR_WRITE, chunk,
                           /*autoend=*/last, /*reload=*/reload);

        for (uint8_t i = 0; i < chunk; i++) {
            if (i2c_wait_flag(hi2c, I2C_ISR_TXIS, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            hi2c->instance->TXDR = *ptr++;
        }

        if (reload) {
            /* Wait for TCR before issuing next NBYTES */
            if (i2c_wait_flag(hi2c, I2C_ISR_TCR, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
        } else {
            /* Wait for STOP condition (AUTOEND set) */
            if (i2c_wait_flag(hi2c, I2C_ISR_STOPF, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            hi2c->instance->ICR = I2C_ICR_STOPCF;
        }

        remaining -= chunk;
    }

    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Master_Receive  (polling)
 * RM0394 §37.4.2 – Master receiver
 * ========================================================================= */
I2C_Status_t I2C_Master_Receive(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                 uint8_t *pdata, uint16_t size,
                                 uint32_t timeout)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_RX;
    hi2c->error = I2C_ERR_NONE;
    i2c_clear_errors(hi2c);

    uint16_t remaining = size;
    uint8_t *ptr = pdata;

    while (remaining > 0) {
        uint8_t chunk = (remaining > I2C_RELOAD_CHUNK) ? I2C_RELOAD_CHUNK
                                                        : (uint8_t)remaining;
        bool last  = (remaining <= I2C_RELOAD_CHUNK);
        bool reload = !last;

        i2c_master_request(hi2c, dev_addr, I2C_DIR_READ, chunk,
                           /*autoend=*/last, /*reload=*/reload);

        for (uint8_t i = 0; i < chunk; i++) {
            if (i2c_wait_flag(hi2c, I2C_ISR_RXNE, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            *ptr++ = (uint8_t)hi2c->instance->RXDR;
        }

        if (reload) {
            if (i2c_wait_flag(hi2c, I2C_ISR_TCR, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
        } else {
            if (i2c_wait_flag(hi2c, I2C_ISR_STOPF, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            hi2c->instance->ICR = I2C_ICR_STOPCF;
        }

        remaining -= chunk;
    }

    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Mem_Write  (polling) – write reg_addr bytes then data bytes
 * Uses RELOAD to avoid generating a STOP between address and data.
 * RM0394 §37.4.3 – Writing data into the slave memory
 * ========================================================================= */
I2C_Status_t I2C_Mem_Write(I2C_Handle_t *hi2c, uint16_t dev_addr,
                            uint16_t reg_addr, uint8_t reg_size,
                            const uint8_t *pdata, uint16_t size,
                            uint32_t timeout)
{
    if (!hi2c || !pdata || (reg_size != 1 && reg_size != 2)) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_TX;
    hi2c->error = I2C_ERR_NONE;
    i2c_clear_errors(hi2c);

    /* Phase 1: Send register address (with RELOAD so no STOP generated) */
    i2c_master_request(hi2c, dev_addr, I2C_DIR_WRITE, reg_size,
                       /*autoend=*/false, /*reload=*/true);

    if (i2c_send_reg_addr(hi2c, reg_addr, reg_size, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Wait TCR – NBYTES sent, hardware requests reload */
    if (i2c_wait_flag(hi2c, I2C_ISR_TCR, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Phase 2: Send data (re-use master transmit logic) */
    uint16_t remaining = size;
    const uint8_t *ptr = pdata;

    while (remaining > 0) {
        uint8_t chunk = (remaining > I2C_RELOAD_CHUNK) ? I2C_RELOAD_CHUNK
                                                        : (uint8_t)remaining;
        bool last  = (remaining <= I2C_RELOAD_CHUNK);

        /* Update CR2 NBYTES (no new START, just update count) */
        uint32_t cr2 = hi2c->instance->CR2;
        cr2 &= ~(I2C_CR2_NBYTES_Msk | I2C_CR2_RELOAD | I2C_CR2_AUTOEND);
        cr2 |= I2C_CR2_SET_NBYTES(chunk);
        if (!last) cr2 |= I2C_CR2_RELOAD;
        else       cr2 |= I2C_CR2_AUTOEND;
        hi2c->instance->CR2 = cr2;

        for (uint8_t i = 0; i < chunk; i++) {
            if (i2c_wait_flag(hi2c, I2C_ISR_TXIS, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            hi2c->instance->TXDR = *ptr++;
        }

        if (!last) {
            if (i2c_wait_flag(hi2c, I2C_ISR_TCR, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
        } else {
            if (i2c_wait_flag(hi2c, I2C_ISR_STOPF, 1, timeout) != I2C_OK) {
                hi2c->state = I2C_STATE_READY;
                return I2C_FAIL;
            }
            hi2c->instance->ICR = I2C_ICR_STOPCF;
        }
        remaining -= chunk;
    }

    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Mem_Read  (polling) – write reg_addr, ReSTART, read data
 * RM0394 §37.4.3 – Reading data from the slave memory
 * ========================================================================= */
I2C_Status_t I2C_Mem_Read(I2C_Handle_t *hi2c, uint16_t dev_addr,
                           uint16_t reg_addr, uint8_t reg_size,
                           uint8_t *pdata, uint16_t size,
                           uint32_t timeout)
{
    if (!hi2c || !pdata || (reg_size != 1 && reg_size != 2)) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_TX;   /* TX phase first */
    hi2c->error = I2C_ERR_NONE;
    i2c_clear_errors(hi2c);

    /* Phase 1: Write register address (SOFTEND – no STOP, allows ReSTART) */
    i2c_master_request(hi2c, dev_addr, I2C_DIR_WRITE, reg_size,
                       /*autoend=*/false, /*reload=*/false);

    if (i2c_send_reg_addr(hi2c, reg_addr, reg_size, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Wait TC (transfer complete, no STOP generated with SOFTEND) */
    if (i2c_wait_flag(hi2c, I2C_ISR_TC, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Phase 2: Repeated START + READ */
    hi2c->state = I2C_STATE_BUSY_RX;
    return I2C_Master_Receive(hi2c, dev_addr, pdata, size, timeout);
    /* Note: I2C_Master_Receive will set state = READY on return */
}

/* =========================================================================
 * I2C_IsDeviceReady  (polling)
 * ========================================================================= */
I2C_Status_t I2C_IsDeviceReady(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                 uint32_t trials, uint32_t timeout)
{
    if (!hi2c) return I2C_FAIL;

    for (uint32_t t = 0; t < trials; t++) {
        i2c_wait_bus_free(hi2c);
        i2c_clear_errors(hi2c);

        /* Generate START + address + STOP with 0 bytes */
        uint32_t cr2 = I2C_CR2_SET_SADD7(dev_addr) |
                       I2C_CR2_SET_NBYTES(0) |
                       I2C_CR2_AUTOEND |
                       I2C_CR2_START;
        hi2c->instance->CR2 = cr2;

        uint32_t start = hi2c->get_tick_ms();
        bool done = false;
        while (!done) {
            uint32_t isr = hi2c->instance->ISR;
            if (isr & I2C_ISR_STOPF) {
                hi2c->instance->ICR = I2C_ICR_STOPCF;
                if (!(isr & I2C_ISR_NACKF)) {
                    hi2c->state = I2C_STATE_READY;
                    return I2C_OK;   /* ACK received → device present */
                }
                hi2c->instance->ICR = I2C_ICR_NACKCF;
                done = true;         /* NACK → try again               */
            }
            if (I2C_ELAPSED(start, hi2c->get_tick_ms()) >= timeout) {
                hi2c->error = I2C_ERR_TIMEOUT;
                hi2c->state = I2C_STATE_READY;
                return I2C_TIMEOUT;
            }
        }
    }

    hi2c->state = I2C_STATE_READY;
    return I2C_FAIL;
}

/* =========================================================================
 * I2C_Slave_Transmit  (polling)
 * ========================================================================= */
I2C_Status_t I2C_Slave_Transmit(I2C_Handle_t *hi2c, const uint8_t *pdata,
                                  uint16_t size, uint32_t timeout)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY &&
        hi2c->state != I2C_STATE_LISTEN) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_TX;
    hi2c->error = I2C_ERR_NONE;

    /* Wait for address match */
    if (i2c_wait_flag(hi2c, I2C_ISR_ADDR, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Check direction: master expects read from us */
    if (!(hi2c->instance->ISR & I2C_ISR_DIR)) {
        hi2c->instance->ICR = I2C_ICR_ADDRCF;
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;    /* master is writing; wrong direction */
    }
    hi2c->instance->ICR = I2C_ICR_ADDRCF;

    for (uint16_t i = 0; i < size; i++) {
        if (i2c_wait_flag(hi2c, I2C_ISR_TXIS, 1, timeout) != I2C_OK) {
            hi2c->state = I2C_STATE_READY;
            return I2C_FAIL;
        }
        hi2c->instance->TXDR = pdata[i];
    }

    /* Wait for STOP or NACK (master ends read) */
    if (i2c_wait_flag(hi2c, I2C_ISR_STOPF, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }
    hi2c->instance->ICR = I2C_ICR_STOPCF | I2C_ICR_NACKCF;
    /* Flush TXDR */
    hi2c->instance->ISR |= I2C_ISR_TXE;

    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Slave_Receive  (polling)
 * ========================================================================= */
I2C_Status_t I2C_Slave_Receive(I2C_Handle_t *hi2c, uint8_t *pdata,
                                 uint16_t size, uint32_t timeout)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY &&
        hi2c->state != I2C_STATE_LISTEN) return I2C_BUSY;

    hi2c->state = I2C_STATE_BUSY_RX;
    hi2c->error = I2C_ERR_NONE;

    /* Wait for address match */
    if (i2c_wait_flag(hi2c, I2C_ISR_ADDR, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }

    /* Direction should be write (master is sending to us) */
    if (hi2c->instance->ISR & I2C_ISR_DIR) {
        hi2c->instance->ICR = I2C_ICR_ADDRCF;
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }
    hi2c->instance->ICR = I2C_ICR_ADDRCF;

    for (uint16_t i = 0; i < size; i++) {
        if (i2c_wait_flag(hi2c, I2C_ISR_RXNE, 1, timeout) != I2C_OK) {
            hi2c->state = I2C_STATE_READY;
            return I2C_FAIL;
        }
        pdata[i] = (uint8_t)hi2c->instance->RXDR;
    }

    if (i2c_wait_flag(hi2c, I2C_ISR_STOPF, 1, timeout) != I2C_OK) {
        hi2c->state = I2C_STATE_READY;
        return I2C_FAIL;
    }
    hi2c->instance->ICR = I2C_ICR_STOPCF;

    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * Interrupt-mode: enable relevant CR1 bits and set state
 * ========================================================================= */
I2C_Status_t I2C_Master_Transmit_IT(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                     const uint8_t *pdata, uint16_t size)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state      = I2C_STATE_BUSY_TX;
    hi2c->error      = I2C_ERR_NONE;
    hi2c->tx_buf     = (uint8_t *)pdata;
    hi2c->tx_count   = size;
    hi2c->dev_addr   = dev_addr;
    hi2c->xfer_size  = size;
    hi2c->xfer_count = 0;

    i2c_clear_errors(hi2c);

    uint8_t chunk = (size > I2C_RELOAD_CHUNK) ? I2C_RELOAD_CHUNK : (uint8_t)size;
    bool last     = (size <= I2C_RELOAD_CHUNK);

    /* Enable TX/error interrupts */
    hi2c->instance->CR1 |= I2C_CR1_TXIE | I2C_CR1_NACKIE |
                            I2C_CR1_STOPIE | I2C_CR1_ERRIE |
                            (last ? I2C_CR1_TCIE : I2C_CR1_TCIE);

    i2c_master_request(hi2c, dev_addr, I2C_DIR_WRITE, chunk,
                       /*autoend=*/last, /*reload=*/!last);
    return I2C_OK;
}

I2C_Status_t I2C_Master_Receive_IT(I2C_Handle_t *hi2c, uint16_t dev_addr,
                                    uint8_t *pdata, uint16_t size)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY) return I2C_BUSY;
    if (i2c_wait_bus_free(hi2c) != I2C_OK) return I2C_BUSY;

    hi2c->state      = I2C_STATE_BUSY_RX;
    hi2c->error      = I2C_ERR_NONE;
    hi2c->rx_buf     = pdata;
    hi2c->rx_count   = size;
    hi2c->dev_addr   = dev_addr;
    hi2c->xfer_size  = size;
    hi2c->xfer_count = 0;

    i2c_clear_errors(hi2c);

    uint8_t chunk = (size > I2C_RELOAD_CHUNK) ? I2C_RELOAD_CHUNK : (uint8_t)size;
    bool last     = (size <= I2C_RELOAD_CHUNK);

    hi2c->instance->CR1 |= I2C_CR1_RXIE | I2C_CR1_NACKIE |
                            I2C_CR1_STOPIE | I2C_CR1_ERRIE | I2C_CR1_TCIE;

    i2c_master_request(hi2c, dev_addr, I2C_DIR_READ, chunk,
                       /*autoend=*/last, /*reload=*/!last);
    return I2C_OK;
}

I2C_Status_t I2C_Slave_Transmit_IT(I2C_Handle_t *hi2c, const uint8_t *pdata,
                                     uint16_t size)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY &&
        hi2c->state != I2C_STATE_LISTEN) return I2C_BUSY;

    hi2c->state    = I2C_STATE_BUSY_TX_LISTEN;
    hi2c->error    = I2C_ERR_NONE;
    hi2c->tx_buf   = (uint8_t *)pdata;
    hi2c->tx_count = size;

    hi2c->instance->CR1 |= I2C_CR1_ADDRIE | I2C_CR1_TXIE |
                            I2C_CR1_STOPIE | I2C_CR1_NACKIE | I2C_CR1_ERRIE;
    return I2C_OK;
}

I2C_Status_t I2C_Slave_Receive_IT(I2C_Handle_t *hi2c, uint8_t *pdata,
                                    uint16_t size)
{
    if (!hi2c || !pdata || size == 0) return I2C_FAIL;
    if (hi2c->state != I2C_STATE_READY &&
        hi2c->state != I2C_STATE_LISTEN) return I2C_BUSY;

    hi2c->state    = I2C_STATE_BUSY_RX_LISTEN;
    hi2c->error    = I2C_ERR_NONE;
    hi2c->rx_buf   = pdata;
    hi2c->rx_count = size;

    hi2c->instance->CR1 |= I2C_CR1_ADDRIE | I2C_CR1_RXIE |
                            I2C_CR1_STOPIE | I2C_CR1_ERRIE;
    return I2C_OK;
}

I2C_Status_t I2C_Slave_Listen_IT(I2C_Handle_t *hi2c)
{
    if (!hi2c) return I2C_FAIL;
    hi2c->state = I2C_STATE_LISTEN;
    hi2c->instance->CR1 |= I2C_CR1_ADDRIE | I2C_CR1_STOPIE | I2C_CR1_ERRIE;
    return I2C_OK;
}

I2C_Status_t I2C_Slave_StopListen_IT(I2C_Handle_t *hi2c)
{
    if (!hi2c) return I2C_FAIL;
    hi2c->instance->CR1 &= ~(I2C_CR1_ADDRIE | I2C_CR1_STOPIE);
    hi2c->state = I2C_STATE_READY;
    return I2C_OK;
}

/* =========================================================================
 * I2C_Abort_IT
 * ========================================================================= */
I2C_Status_t I2C_Abort_IT(I2C_Handle_t *hi2c)
{
    if (!hi2c) return I2C_FAIL;
    /* Generate STOP if master and bus is active */
    if (hi2c->instance->ISR & I2C_ISR_BUSY) {
        hi2c->instance->CR2 |= I2C_CR2_STOP;
    }
    /* Disable all interrupts */
    hi2c->instance->CR1 &= ~(I2C_CR1_TXIE | I2C_CR1_RXIE | I2C_CR1_ADDRIE |
                              I2C_CR1_NACKIE | I2C_CR1_STOPIE | I2C_CR1_TCIE |
                              I2C_CR1_ERRIE);
    i2c_clear_errors(hi2c);
    hi2c->state  = I2C_STATE_READY;
    hi2c->error  = I2C_ERR_NONE;
    return I2C_OK;
}

/* =========================================================================
 * I2C_GetError / I2C_GetState
 * ========================================================================= */
I2C_Error_t I2C_GetError(I2C_Handle_t *hi2c)
{
    I2C_Error_t err = hi2c->error;
    hi2c->error = I2C_ERR_NONE;
    return err;
}

I2C_State_t I2C_GetState(I2C_Handle_t *hi2c)
{
    return hi2c->state;
}

/* =========================================================================
 * I2C_EV_IRQHandler – Event interrupt handler
 * Handles: TXIS, RXNE, ADDR, NACKF, STOPF, TC, TCR
 * ========================================================================= */
void I2C_EV_IRQHandler(I2C_Handle_t *hi2c)
{
    uint32_t isr = hi2c->instance->ISR;
    uint32_t cr1 = hi2c->instance->CR1;

    /* ── TXIS: transmit buffer empty, load next byte ── */
    if ((isr & I2C_ISR_TXIS) && (cr1 & I2C_CR1_TXIE)) {
        if (hi2c->tx_count > 0) {
            hi2c->instance->TXDR = *hi2c->tx_buf++;
            hi2c->tx_count--;
            hi2c->xfer_count++;
        }
    }

    /* ── RXNE: data received, drain RXDR ── */
    if ((isr & I2C_ISR_RXNE) && (cr1 & I2C_CR1_RXIE)) {
        if (hi2c->rx_count > 0) {
            *hi2c->rx_buf++ = (uint8_t)hi2c->instance->RXDR;
            hi2c->rx_count--;
            hi2c->xfer_count++;
        }
    }

    /* ── TCR: transfer complete reload – load next chunk ── */
    if ((isr & I2C_ISR_TCR) && (cr1 & I2C_CR1_TCIE)) {
        uint16_t remaining = (hi2c->state == I2C_STATE_BUSY_TX) ?
                              hi2c->tx_count : hi2c->rx_count;
        uint8_t  chunk = (remaining > I2C_RELOAD_CHUNK) ?
                          I2C_RELOAD_CHUNK : (uint8_t)remaining;
        bool     last  = (remaining <= I2C_RELOAD_CHUNK);

        uint32_t cr2 = hi2c->instance->CR2;
        cr2 &= ~(I2C_CR2_NBYTES_Msk | I2C_CR2_RELOAD | I2C_CR2_AUTOEND);
        cr2 |= I2C_CR2_SET_NBYTES(chunk);
        if (!last) cr2 |= I2C_CR2_RELOAD;
        else       cr2 |= I2C_CR2_AUTOEND;
        hi2c->instance->CR2 = cr2;
    }

    /* ── TC: transfer complete (SOFTEND, master mode) ── */
    if ((isr & I2C_ISR_TC) && (cr1 & I2C_CR1_TCIE)) {
        /* Generate STOP */
        hi2c->instance->CR2 |= I2C_CR2_STOP;
    }

    /* ── STOPF: STOP detected ── */
    if ((isr & I2C_ISR_STOPF) && (cr1 & I2C_CR1_STOPIE)) {
        hi2c->instance->ICR = I2C_ICR_STOPCF;
        /* Disable data interrupts */
        hi2c->instance->CR1 &= ~(I2C_CR1_TXIE | I2C_CR1_RXIE | I2C_CR1_TCIE);

        if (hi2c->state == I2C_STATE_BUSY_TX ||
            hi2c->state == I2C_STATE_BUSY_TX_LISTEN) {
            /* Flush TXDR */
            hi2c->instance->ISR |= I2C_ISR_TXE;
            hi2c->state = I2C_STATE_READY;
            if (hi2c->cb_master_tx_complete) hi2c->cb_master_tx_complete(hi2c);
        } else if (hi2c->state == I2C_STATE_BUSY_RX ||
                   hi2c->state == I2C_STATE_BUSY_RX_LISTEN) {
            hi2c->state = I2C_STATE_READY;
            if (hi2c->cb_master_rx_complete) hi2c->cb_master_rx_complete(hi2c);
        } else if (hi2c->state == I2C_STATE_LISTEN) {
            if (hi2c->cb_listen_complete) hi2c->cb_listen_complete(hi2c);
        }
    }

    /* ── ADDR: address matched (slave mode) ── */
    if ((isr & I2C_ISR_ADDR) && (cr1 & I2C_CR1_ADDRIE)) {
        uint16_t addr = (uint16_t)((isr & I2C_ISR_ADDCODE_Msk) >>
                                    I2C_ISR_ADDCODE_Pos);
        uint8_t  dir  = (isr & I2C_ISR_DIR) ? 1U : 0U;
        hi2c->instance->ICR = I2C_ICR_ADDRCF;
        hi2c->slave_addr = addr;
        if (hi2c->cb_addr_match) hi2c->cb_addr_match(hi2c, dir, addr);
    }

    /* ── NACKF: NACK received ── */
    if ((isr & I2C_ISR_NACKF) && (cr1 & I2C_CR1_NACKIE)) {
        hi2c->instance->ICR = I2C_ICR_NACKCF;
        hi2c->error |= I2C_ERR_NACK;
        /* STOP will follow; handled in STOPF branch */
    }
}

/* =========================================================================
 * I2C_ER_IRQHandler – Error interrupt handler
 * Handles: BERR, ARLO, OVR, PECERR, TIMEOUT, ALERT
 * ========================================================================= */
void I2C_ER_IRQHandler(I2C_Handle_t *hi2c)
{
    uint32_t isr = hi2c->instance->ISR;

    if (isr & I2C_ISR_BERR)    { hi2c->error |= I2C_ERR_BERR;    hi2c->instance->ICR = I2C_ICR_BERRCF;   }
    if (isr & I2C_ISR_ARLO)    { hi2c->error |= I2C_ERR_ARLO;    hi2c->instance->ICR = I2C_ICR_ARLOCF;   }
    if (isr & I2C_ISR_OVR)     { hi2c->error |= I2C_ERR_OVR;     hi2c->instance->ICR = I2C_ICR_OVRCF;    }
    if (isr & I2C_ISR_PECERR)  { hi2c->error |= I2C_ERR_PECERR;  hi2c->instance->ICR = I2C_ICR_PECCF;    }
    if (isr & I2C_ISR_TIMEOUT) { hi2c->error |= I2C_ERR_TIMEOUT; hi2c->instance->ICR = I2C_ICR_TIMOUTCF; }

    /* Disable all I2C interrupts on error */
    hi2c->instance->CR1 &= ~(I2C_CR1_TXIE  | I2C_CR1_RXIE  | I2C_CR1_ADDRIE |
                              I2C_CR1_NACKIE | I2C_CR1_STOPIE | I2C_CR1_TCIE  |
                              I2C_CR1_ERRIE);

    hi2c->state = I2C_STATE_ERROR;
    if (hi2c->cb_error) hi2c->cb_error(hi2c);
}
